Wrzuc 4 tekstury PNG 16x16 do assets/smp/textures/item/:
pospolity_klucz.png
rzadki_klucz.png
epicki_klucz.png
legendarny_klucz.png
